const modal = document.querySelector(".confirm-modal");
const columnsContainer = document.querySelector(".columns");
const columns = columnsContainer.querySelectorAll(".column");
const dialog = document.querySelector("dialog");

let currentTask = null;

//* functions

const handleDragover = (event) => {
  event.preventDefault(); // allow drop

  const draggedTask = document.querySelector(".dragging");
  const target = event.target.closest(".task, .tasks");

  if (!target || target === draggedTask) return;

  if (target.classList.contains("tasks")) {
    // target is the tasks element
    const lastTask = target.lastElementChild;
    if (!lastTask) {
      // tasks is empty
      target.appendChild(draggedTask);
    } else {
      const { bottom } = lastTask.getBoundingClientRect();
      event.clientY > bottom && target.appendChild(draggedTask);
    }
  } else {
    // target is another
    const { top, height } = target.getBoundingClientRect();
    const distance = top + height / 2;

    if (event.clientY < distance) {
      target.before(draggedTask);
    } else {
      target.after(draggedTask);
    }
  }
};

const handleDrop = (event) => {
  event.preventDefault();
};

const handleDragend = (event) => {
  event.target.classList.remove("dragging");
};

const handleDragstart = (event) => {
  event.dataTransfer.effectsAllowed = "move";
  event.dataTransfer.setData("text/plain", "");
  requestAnimationFrame(() => event.target.classList.add("dragging"));
};

const handleDelete = (event) => {
  currentTask = event.target.closest(".task");

  // show preview
  modal.querySelector(".preview").innerText = currentTask.innerText.substring(
    0,
    100
  );

  modal.showModal();
};

const handleEdit = (event) => {
  const task = event.target.closest(".task");
  const input = createTaskInput(task.innerText);
  task.replaceWith(input);
  input.focus();

  // move cursor to the end
  const selection = window.getSelection();
  selection.selectAllChildren(input);
  selection.collapseToEnd();
};

const handleBlur = (event) => {
  const input = event.target;
  const content = input.innerText.trim() || "Untitled";
  const task = createTask(content.replace(/\n/g, "<br>"));
  input.replaceWith(task);
};

const handleAdd = (event) => {
  const tasksEl = event.target.closest(".column").lastElementChild;
  const input = createTaskInput();
  tasksEl.appendChild(input);
  input.focus();
};

const updateTaskCount = (column) => {
  const tasks = column.querySelector(".tasks").children;
  const taskCount = tasks.length;
  column.querySelector(".column-title h3").dataset.tasks = taskCount;
};

const observeTaskChanges = () => {
  for (const column of columns) {
    const observer = new MutationObserver(() => updateTaskCount(column));
    observer.observe(column.querySelector(".tasks"), { childList: true });
  }
};

observeTaskChanges();

const defaultCategories = [
  { name: "To Do", class: "todo-col" },
  { name: "In Progress", class: "inprogress-col" },
  { name: "For Review", class: "review-col" },
  { name: "Done", class: "done-col" }
];

function createCategory({ name, class: className }, removable = false) {
  const col = document.createElement("div");
  col.className = `column ${className || ""}`;
  col.innerHTML = `
    <div class="column-title">
      <h3 data-tasks="0">${name}</h3>
      ${removable ? '<button class="remove-category-btn" title="Rimuovi categoria">&times;</button>' : ""}
    </div>
    <div class="tasks"></div>
    <button class="add-task-btn btn btn-outline btn-success">+ Nuova Task</button>
  `;
  // Eventi per drag&drop, aggiunta/rimozione task/categoria...
  return col;
}

// All'avvio
columnsContainer.innerHTML = ""; // Pulisci
defaultCategories.forEach(cat => columnsContainer.appendChild(createCategory(cat)));

// Pulsante per aggiungere nuove categorie
const addCategoryBtn = document.createElement("button");
addCategoryBtn.textContent = "+ Nuova Categoria";
addCategoryBtn.className = "btn btn-primary";
addCategoryBtn.onclick = () => {
  const name = prompt("Nome nuova categoria?");
  if (name) columnsContainer.appendChild(createCategory({ name }, true));
};
columnsContainer.parentElement.insertBefore(addCategoryBtn, columnsContainer.nextSibling);

// Event delegation per rimuovere categorie
columnsContainer.addEventListener("click", e => {
  if (e.target.classList.contains("remove-category-btn")) {
    e.target.closest(".column").remove();
  }
});

// Event delegation per aggiungere task
columnsContainer.addEventListener("click", e => {
  if (e.target.classList.contains("add-task-btn")) {
    const tasksEl = e.target.closest(".column").querySelector(".tasks");
    const content = prompt("Nome della nuova task?");
    if (content && content.trim()) {
      tasksEl.appendChild(createTask(content.trim()));
    }
  }
});

const createTask = (content) => {
  const task = document.createElement("div");
  // Applica qui tutte le classi di card e larghezza
  task.className = "task card w-full bg-base-100 card-sm shadow-md mb-2";
  task.draggable = true;
  task.innerHTML = `
    <div class="card-body p-4">
      <h2 class="card-title">${content}</h2>
      <div class="justify-end card-actions mt-2">
        <button data-edit class="btn btn-info"><i class="bi bi-pencil-square"></i></button>
        <button data-delete class="btn btn-error"><i class="bi bi-trash"></i></button>
      </div>
    </div>
  `;
  task.addEventListener("dragstart", handleDragstart);
  task.addEventListener("dragend", handleDragend);
  return task;
};

const createTaskInput = (text = "") => {
  const input = document.createElement("div");
  input.className = "task-input";
  input.dataset.placeholder = "Task name";
  input.contentEditable = true;
  input.innerText = text;
  input.addEventListener("blur", handleBlur);
  return input;
};

//* event listeners

// dragover and drop
tasksElements = columnsContainer.querySelectorAll(".tasks");
for (const tasksEl of tasksElements) {
  tasksEl.addEventListener("dragover", handleDragover);
  tasksEl.addEventListener("drop", handleDrop);
}

// add, edit and delete task
columnsContainer.addEventListener("click", (event) => {
  if (event.target.closest("button[data-add]")) {
    handleAdd(event);
  } else if (event.target.closest("button[data-edit]")) {
    handleEdit(event);
  } else if (event.target.closest("button[data-delete]")) {
    handleDelete(event);
  }
});

// confirm deletion
modal.addEventListener("submit", () => currentTask && currentTask.remove());

// cancel deletion
modal.querySelector("#cancel").addEventListener("click", () => modal.close());

// clear current task
modal.addEventListener("close", () => (currentTask = null));