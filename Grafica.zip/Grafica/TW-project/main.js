const modal = document.querySelector(".confirm-modal");
const columnsContainer = document.querySelector(".columns");
// Usa una query più generica per le colonne, dato che le ricrei in createCategory
let columns = document.querySelectorAll(".column");
const dialog = document.querySelector("dialog");

let currentTask = null;

//* Utility per il Countdown
// Funzione per formattare i numeri del countdown (aggiunge lo zero iniziale)
const formatTime = (value) => value < 10 ? `0${value}` : value;

// Funzione per calcolare e renderizzare il countdown
const updateCountdown = (taskElement) => {
    const countdownElement = taskElement.querySelector('.task-countdown');
    const dueDateString = countdownElement.getAttribute('data-due-date');
    if (!dueDateString) return;
    
    const targetDate = new Date(dueDateString).getTime();
    const now = new Date().getTime();
    let distance = targetDate - now;

    // Se il tempo è scaduto
    if (distance < 0) {
        // Ferma l'aggiornamento se il timerId è stato salvato
        if (countdownElement.timerId) clearInterval(countdownElement.timerId); 
        countdownElement.innerHTML = '<span class="text-error font-bold text-sm">SCADUTA!</span>';
        return;
    }

    // Calcoli per giorni, ore, minuti e secondi
    const days = Math.floor(distance / (1000 * 60 * 60 * 24));
    distance %= (1000 * 60 * 60 * 24); // Rimuovi i giorni
    const hours = Math.floor(distance / (1000 * 60 * 60));
    distance %= (1000 * 60 * 60); // Rimuovi le ore
    const minutes = Math.floor(distance / (1000 * 60));
    distance %= (1000 * 60); // Rimuovi i minuti
    const seconds = Math.floor(distance / 1000);

    // Genera l'HTML del countdown
    countdownElement.innerHTML = `
        <span class="countdown font-mono text-sm">
            <span style="--value:${days};">${formatTime(days)}</span>g
        </span>
        <span class="countdown font-mono text-sm">
            <span style="--value:${hours};">${formatTime(hours)}</span>h
        </span>
        <span class="countdown font-mono text-sm">
            <span style="--value:${minutes};">${formatTime(minutes)}</span>m
        </span>
        <span class="countdown font-mono text-sm">
            <span style="--value:${seconds};">${formatTime(seconds)}</span>s
        </span>
    `;
};

// Avvia il countdown e lo ripete ogni secondo
const startTaskCountdown = (taskElement) => {
    const countdownElement = taskElement.querySelector('.task-countdown');
    if (!countdownElement || !countdownElement.getAttribute('data-due-date')) return;

    // Esegue la funzione immediatamente
    updateCountdown(taskElement); 
    
    // Imposta l'intervallo e salva il suo ID
    const timerId = setInterval(() => {
        updateCountdown(taskElement);
    }, 1000);

    countdownElement.timerId = timerId;
};

// Funzione per fermare il countdown
const stopTaskCountdown = (taskElement) => {
    const countdownElement = taskElement.querySelector('.task-countdown');
    if (countdownElement && countdownElement.timerId) {
        clearInterval(countdownElement.timerId);
    }
};

//* functions

const handleDragover = (event) => {
    event.preventDefault(); // allow drop

    const draggedTask = document.querySelector(".dragging");
    const target = event.target.closest(".task, .tasks");

    if (!target || target === draggedTask) return;

    if (target.classList.contains("tasks")) {
        // target is the tasks element
        const lastTask = target.lastElementChild;
        if (!lastTask) {
            // tasks is empty
            target.appendChild(draggedTask);
        } else {
            const { bottom } = lastTask.getBoundingClientRect();
            event.clientY > bottom && target.appendChild(draggedTask);
        }
    } else {
        // target is another task
        const { top, height } = target.getBoundingClientRect();
        const distance = top + height / 2;

        if (event.clientY < distance) {
            target.before(draggedTask);
        } else {
            target.after(draggedTask);
        }
    }
};

const handleDrop = (event) => {
    event.preventDefault();
};

const handleDragend = (event) => {
    event.target.classList.remove("dragging");
};

const handleDragstart = (event) => {
    event.dataTransfer.effectsAllowed = "move";
    event.dataTransfer.setData("text/plain", "");
    requestAnimationFrame(() => event.target.classList.add("dragging"));
};

const handleDelete = (event) => {
    currentTask = event.target.closest(".task");

    // show preview
    modal.querySelector(".preview").innerText = currentTask.querySelector('.card-title').innerText.substring(
        0,
        100
    );

    modal.showModal();
};

const handleEdit = (event) => {
    const task = event.target.closest(".task");
    const taskTitle = task.querySelector('.card-title'); // Seleziona solo il titolo per l'editing
    
    // Crea un input per modificare solo il titolo
    const input = createTaskInput(taskTitle.innerText);
    taskTitle.replaceWith(input);
    input.focus();

    // move cursor to the end
    const selection = window.getSelection();
    selection.selectAllChildren(input);
    selection.collapseToEnd();
};

const handleBlur = (event) => {
    const input = event.target;
    const content = input.innerText.trim() || "Untitled";
    
    // Crea un nuovo elemento h2 per il titolo
    const newTitle = document.createElement('h2');
    newTitle.className = "card-title";
    newTitle.innerHTML = content.replace(/\n/g, "<br>");
    
    // Trova la task parente e sostituisci l'input con il nuovo titolo
    const task = input.closest('.task');
    input.replaceWith(newTitle);
};

const handleAdd = (event) => {
    const tasksEl = event.target.closest(".column").lastElementChild;
    const input = createTaskInput();
    tasksEl.appendChild(input);
    input.focus();
};

const updateTaskCount = (column) => {
    const tasks = column.querySelector(".tasks").children;
    const taskCount = tasks.length;
    column.querySelector(".column-title h3").dataset.tasks = taskCount;
};

const observeTaskChanges = () => {
    // Riassegna columns per includere le nuove colonne
    columns = document.querySelectorAll(".column");
    for (const column of columns) {
        // Assicurati di non osservare due volte la stessa colonna se questa funzione viene chiamata più volte
        if (!column.observer) {
            const observer = new MutationObserver(() => updateTaskCount(column));
            observer.observe(column.querySelector(".tasks"), { childList: true });
            column.observer = observer; // Salva l'observer per evitare duplicati
        }
    }
};

// Chiama observeTaskChanges subito dopo la definizione
// e anche dopo aver aggiunto/ricreato le colonne iniziali
// observeTaskChanges(); // Sarà chiamata dopo la creazione delle categorie

const defaultCategories = [
    { name: "To Do", class: "todo-col" },
    { name: "In Progress", class: "inprogress-col" },
    { name: "For Review", class: "review-col" },
    { name: "Done", class: "done-col" }
];

function createCategory({ name, class: className }, removable = false) {
    const col = document.createElement("div");
    col.className = `column ${className || ""}`;
    col.innerHTML = `
        <div class="column-title">
            <h3 data-tasks="0">${name}</h3>
            ${removable ? '<button class="remove-category-btn" title="Rimuovi categoria">&times;</button>' : ""}
            <button data-add class="btn btn-circle btn-success btn-xs ms-auto"><i class="bi bi-plus"></i></button>
        </div>
        <div class="tasks"></div>
    `;
    // Aggiunto l'evento drag/drop al div tasks per le nuove colonne
    const tasksEl = col.querySelector(".tasks");
    tasksEl.addEventListener("dragover", handleDragover);
    tasksEl.addEventListener("drop", handleDrop);
    
    return col;
}

// All'avvio
columnsContainer.innerHTML = ""; // Pulisci il container dai div statici
defaultCategories.forEach(cat => columnsContainer.appendChild(createCategory(cat)));
observeTaskChanges(); // Osserva le colonne appena create

// Pulsante per aggiungere nuove categorie
const addCategoryBtn = document.createElement("button");
addCategoryBtn.textContent = "+ Nuova Categoria";
addCategoryBtn.className = "btn btn-primary mt-4";
addCategoryBtn.onclick = () => {
    const name = prompt("Nome nuova categoria?");
    if (name) {
        columnsContainer.appendChild(createCategory({ name }, true));
        observeTaskChanges(); // Osserva la nuova colonna
    }
};
// Cerca il genitore del columnsContainer nel DOM e inserisci il pulsante
const mainContainer = columnsContainer.closest('.container');
if (mainContainer) {
    mainContainer.appendChild(addCategoryBtn);
} else {
    columnsContainer.parentElement.insertBefore(addCategoryBtn, columnsContainer.nextSibling);
}


// Event delegation per rimuovere categorie
columnsContainer.addEventListener("click", e => {
    if (e.target.classList.contains("remove-category-btn")) {
        e.target.closest(".column").remove();
    }
});

// Event delegation per aggiungere task (modificato per usare prompt della scadenza)
columnsContainer.addEventListener("click", e => {
    // Gestione del click sul pulsante data-add
    if (e.target.closest("button[data-add]")) {
        const tasksEl = e.target.closest(".column").querySelector(".tasks");
        const content = prompt("Nome della nuova task?");
        
        if (content && content.trim()) {
            const dueDate = prompt("Data e ora di scadenza (es: 2025-12-31T23:59:00)? Lascia vuoto per nessuna scadenza.");
            
            const newTask = createTask(content.trim(), dueDate);
            tasksEl.appendChild(newTask);
            
            // Avvia il countdown solo se è stata fornita una data
            if (dueDate) {
                startTaskCountdown(newTask);
            }
        }
    }
    // Gestione di edit e delete (già presenti sotto, ma meglio gestirli qui)
    else if (e.target.closest("button[data-edit]")) {
        handleEdit(e);
    } else if (e.target.closest("button[data-delete]")) {
        handleDelete(e);
    }
});


const createTask = (content, dueDate = null) => {
    const task = document.createElement("div");
    // Aggiungo una classe per distinguere facilmente l'elemento task
    task.className = "task card w-full bg-base-100 card-sm shadow-md mb-2"; 
    task.draggable = true;
    
    // Prepara l'HTML per il countdown
    let countdownHTML = '';
    if (dueDate) {
        // La data di scadenza viene salvata in un attributo data- per JS
        countdownHTML = `<div class="task-countdown flex gap-2 justify-end text-xs mt-2" data-due-date="${dueDate}"></div>`;
    }

    task.innerHTML = `
        <div class="card-body p-4">
            <h2 class="card-title">${content}</h2>
            ${countdownHTML}
            <div class="justify-end card-actions mt-2">
                <button data-edit class="btn btn-info btn-xs"><i class="bi bi-pencil-square"></i></button>
                <button data-delete class="btn btn-error btn-xs"><i class="bi bi-trash"></i></button>
            </div>
        </div>
    `;
    task.addEventListener("dragstart", handleDragstart);
    task.addEventListener("dragend", handleDragend);
    return task;
};

// Mantenuta come da originale (usata per l'editing in-place)
const createTaskInput = (text = "") => {
    const input = document.createElement("div");
    input.className = "task-input card-title"; // Aggiunta card-title per mantenere lo stile
    input.dataset.placeholder = "Task name";
    input.contentEditable = true;
    input.innerText = text;
    input.addEventListener("blur", handleBlur);
    return input;
};

//* event listeners

// dragover and drop
// Rimosso il loop qui perché gli eventi drag/drop sono ora aggiunti
// quando viene creata una nuova categoria/all'avvio.

// Aggiungi un ascoltatore per tutti i contenitori di task esistenti all'avvio
document.querySelectorAll(".tasks").forEach(tasksEl => {
    tasksEl.addEventListener("dragover", handleDragover);
    tasksEl.addEventListener("drop", handleDrop);
});


// confirm deletion (modificato per fermare il countdown)
modal.addEventListener("submit", () => {
    if (currentTask) {
        stopTaskCountdown(currentTask); // Ferma il timer
        currentTask.remove(); // Rimuovi l'elemento
    }
});

// cancel deletion
modal.querySelector("#cancel").addEventListener("click", () => modal.close());

// clear current task
modal.addEventListener("close", () => (currentTask = null));

// All'avvio, cerca tutte le task esistenti nel DOM e avvia i countdown
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.task').forEach(task => {
        startTaskCountdown(task);
    });
});