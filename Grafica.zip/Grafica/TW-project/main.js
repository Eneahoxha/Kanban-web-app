const modal = document.querySelector(".confirm-modal");
const columnsContainer = document.querySelector(".columns");
let columns = document.querySelectorAll(".column");
const dialog = document.querySelector("dialog");
let currentTask = null;

// Utility
const formatTime = (value) => value < 10 ? `0${value}` : value;

// ✅ Nuova funzione: colora la task in base alla scadenza
const updateTaskColor = (taskElement) => {
    const countdownElement = taskElement.querySelector('.task-countdown');
    const dueDateString = countdownElement?.getAttribute('data-due-date');
    if (!dueDateString) return;

    const targetDate = new Date(dueDateString).getTime();
    const now = new Date().getTime();
    const distanceInDays = Math.floor((targetDate - now) / (1000 * 60 * 60 * 24));

    taskElement.classList.remove('bg-green-100', 'bg-yellow-100', 'bg-red-100');

    if (distanceInDays > 7) {
        taskElement.classList.add('bg-green-100');
    } else if (distanceInDays >= 1) {
        taskElement.classList.add('bg-yellow-100');
    } else {
        taskElement.classList.add('bg-red-100');
    }
};

// Countdown
const updateCountdown = (taskElement) => {
    const countdownElement = taskElement.querySelector('.task-countdown');
    const dueDateString = countdownElement.getAttribute('data-due-date');
    if (!dueDateString) return;

    const targetDate = new Date(dueDateString).getTime();
    const now = new Date().getTime();
    let distance = targetDate - now;

    if (distance < 0) {
        if (countdownElement.timerId) clearInterval(countdownElement.timerId);
        countdownElement.innerHTML = '<span class="text-error font-bold text-sm">SCADUTA!</span>';
        updateTaskColor(taskElement);
        return;
    }

    const days = Math.floor(distance / (1000 * 60 * 60 * 24));
    distance %= (1000 * 60 * 60 * 24);
    const hours = Math.floor(distance / (1000 * 60 * 60));
    distance %= (1000 * 60 * 60);
    const minutes = Math.floor(distance / (1000 * 60));
    distance %= (1000 * 60);
    const seconds = Math.floor(distance / 1000);

    countdownElement.innerHTML = `
        <span class="countdown font-mono text-sm"><span style="--value:${days};">${formatTime(days)}</span>g</span>
        <span class="countdown font-mono text-sm"><span style="--value:${hours};">${formatTime(hours)}</span>h</span>
        <span class="countdown font-mono text-sm"><span style="--value:${minutes};">${formatTime(minutes)}</span>m</span>
        <span class="countdown font-mono text-sm"><span style="--value:${seconds};">${formatTime(seconds)}</span>s</span>
    `;

    updateTaskColor(taskElement);
};

const startTaskCountdown = (taskElement) => {
    const countdownElement = taskElement.querySelector('.task-countdown');
    if (!countdownElement || !countdownElement.getAttribute('data-due-date')) return;

    updateCountdown(taskElement);
    const timerId = setInterval(() => updateCountdown(taskElement), 1000);
    countdownElement.timerId = timerId;
};

const stopTaskCountdown = (taskElement) => {
    const countdownElement = taskElement.querySelector('.task-countdown');
    if (countdownElement && countdownElement.timerId) {
        clearInterval(countdownElement.timerId);
    }
};

// Funzioni drag & drop
const handleDragover = (event) => {
    event.preventDefault();
    const draggedTask = document.querySelector(".dragging");
    const target = event.target.closest(".task, .tasks");
    if (!target || target === draggedTask) return;

    if (target.classList.contains("tasks")) {
        const lastTask = target.lastElementChild;
        if (!lastTask) {
            target.appendChild(draggedTask);
        } else {
            const { bottom } = lastTask.getBoundingClientRect();
            if (event.clientY > bottom) target.appendChild(draggedTask);
        }
    } else {
        const { top, height } = target.getBoundingClientRect();
        const distance = top + height / 2;
        if (event.clientY < distance) {
            target.before(draggedTask);
        } else {
            target.after(draggedTask);
        }
    }
};

const handleDrop = (event) => {
    event.preventDefault();
};

const handleDragend = (event) => {
    event.target.classList.remove("dragging");
};

const handleDragstart = (event) => {
    event.dataTransfer.effectsAllowed = "move";
    event.dataTransfer.setData("text/plain", "");
    requestAnimationFrame(() => event.target.classList.add("dragging"));
};

// Task management
const handleDelete = (event) => {
    currentTask = event.target.closest(".task");
    modal.querySelector(".preview").innerText = currentTask.querySelector('.card-title').innerText.substring(0, 100);
    modal.showModal();
};

const handleEdit = (event) => {
    const task = event.target.closest(".task");
    const taskTitle = task.querySelector('.card-title');
    const input = createTaskInput(taskTitle.innerText);
    taskTitle.replaceWith(input);
    input.focus();

    const selection = window.getSelection();
    selection.selectAllChildren(input);
    selection.collapseToEnd();
};

const handleBlur = (event) => {
    const input = event.target;
    const content = input.innerText.trim() || "Untitled";
    const newTitle = document.createElement('h2');
    newTitle.className = "card-title";
    newTitle.innerHTML = content.replace(/\n/g, "<br>");
    const task = input.closest('.task');
    input.replaceWith(newTitle);
};

const handleAdd = (event) => {
    const tasksEl = event.target.closest(".column").lastElementChild;
    const input = createTaskInput();
    tasksEl.appendChild(input);
    input.focus();
};

const updateTaskCount = (column) => {
    const tasks = column.querySelector(".tasks").children;
    const taskCount = tasks.length;
    column.querySelector(".column-title h3").dataset.tasks = taskCount;
};

const observeTaskChanges = () => {
    columns = document.querySelectorAll(".column");
    for (const column of columns) {
        if (!column.observer) {
            const observer = new MutationObserver(() => updateTaskCount(column));
            observer.observe(column.querySelector(".tasks"), { childList: true });
            column.observer = observer;
        }
    }
};

// Categorie
const defaultCategories = [
    { name: "To Do", class: "todo-col" },
    { name: "In Progress", class: "inprogress-col" },
    { name: "For Review", class: "review-col" },
    { name: "Done", class: "done-col" }
];

function createCategory({ name, class: className }, removable = false) {
    const col = document.createElement("div");
    col.className = `column ${className || ""}`;
    col.innerHTML = `
        <div class="column-title">
            <h3 data-tasks="0">${name}</h3>
            ${removable ? '<button class="remove-category-btn" title="Rimuovi categoria">&times;</button>' : ""}
            <button data-add class="btn btn-circle btn-success btn-xs ms-auto"><i class="bi bi-plus"></i></button>
        </div>
        <div class="tasks"></div>
    `;
    const tasksEl = col.querySelector(".tasks");
    tasksEl.addEventListener("dragover", handleDragover);
    tasksEl.addEventListener("drop", handleDrop);
    return col;
}

// Inizializza
columnsContainer.innerHTML = "";
defaultCategories.forEach(cat => columnsContainer.appendChild(createCategory(cat)));
observeTaskChanges();

const addCategoryBtn = document.createElement("button");
addCategoryBtn.textContent = "+ Nuova Categoria";
addCategoryBtn.className = "btn btn-primary mt-4";
addCategoryBtn.onclick = () => {
    const name = prompt("Nome nuova categoria?");
    if (name) {
        columnsContainer.appendChild(createCategory({ name }, true));
        observeTaskChanges();
    }
};
const mainContainer = columnsContainer.closest('.container');
mainContainer ? mainContainer.appendChild(addCategoryBtn) : columnsContainer.parentElement.insertBefore(addCategoryBtn, columnsContainer.nextSibling);

// Delegazioni
columnsContainer.addEventListener("click", e => {
    if (e.target.classList.contains("remove-category-btn")) {
        e.target.closest(".column").remove();
    }
});

columnsContainer.addEventListener("click", e => {
    if (e.target.closest("button[data-add]")) {
        const tasksEl = e.target.closest(".column").querySelector(".tasks");
        const content = prompt("Nome della nuova task?");
        if (content && content.trim()) {
            const dueDate = prompt("Data e ora di scadenza (es: 2025-12-31T23:59:00)? Lascia vuoto per nessuna scadenza.");
            const newTask = createTask(content.trim(), dueDate);
            tasksEl.appendChild(newTask);
            if (dueDate) startTaskCountdown(newTask);
        }
    } else if (e.target.closest("button[data-edit]")) {
        handleEdit(e);
    } else if (e.target.closest("button[data-delete]")) {
        handleDelete(e);
    }
});

// Crea task
const createTask = (content, dueDate = null) => {
    const task = document.createElement("div");
    task.className = "task card w-full bg-base-100 card-sm shadow-md mb-2";
    task.draggable = true;

    let countdownHTML = '';
    if (dueDate) {
        countdownHTML = `<div class="task-countdown flex gap-2 justify-end text-xs mt-2" data-due-date="${dueDate}"></div>`;
    }

    task.innerHTML = `
        <div class="card-body p-4">
            <h2 class="card-title">${content}</h2>
            ${countdownHTML}
            <div class="justify-end card-actions mt-2">
                <button data-edit class="btn btn-info btn-xs"><i class="bi bi-pencil-square"></i></button>
                <button data-delete class="btn btn-error btn-xs"><i class="bi bi-trash"></i></button>
            </div>
        </div>
    `;
    task.addEventListener("dragstart", handleDragstart);
    task.addEventListener("dragend", handleDragend);
    return task;
};

const createTaskInput = (text = "") => {
    const input = document.createElement("div");
    input.className = "task-input card-title";
    input.dataset.placeholder = "Task name";
    input.contentEditable = true;
    input.innerText = text;
    input.addEventListener("blur", handleBlur);
    return input;
};

// Eventi finali
document.querySelectorAll(".tasks").forEach(tasksEl => {
    tasksEl.addEventListener("dragover", handleDragover);
    tasksEl.addEventListener("drop", handleDrop);
});

modal.addEventListener("submit", () => {
    if (currentTask) {
        stopTaskCountdown(currentTask);
        currentTask.remove();
    }
});
modal.querySelector("#cancel").addEventListener("click", () => modal.close());
modal.addEventListener("close", () => (currentTask = null));

document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.task').forEach(task => {
        startTaskCountdown(task);
    });
});
