const modal = document.querySelector(".confirm-modal");
const columnsContainer = document.querySelector(".columns");
let columns = document.querySelectorAll(".column");
const dialog = document.querySelector("dialog");
let currentTask = null;

// Utility
const formatTime = (value) => value < 10 ? `0${value}` : value;

// Nuova funzione: colora la task in base alla scadenza
const updateTaskColor = (taskElement) => {
    const countdownElement = taskElement.querySelector('.task-countdown');
    const dueDateString = countdownElement?.getAttribute('data-due-date');
    const isDone = taskElement.closest('.done-col');
    const isExpired = taskElement.closest('.expired-col');

    // Rimuovi tutte le classi di colore esistenti
    taskElement.classList.remove(
        'bg-green-500', 'bg-yellow-400', 'bg-red-600', 'bg-lime-500', 'bg-orange-500', 'bg-pink-600', 'text-white'
    );

    // Se la task è nella colonna Done
    if (isDone) {
        taskElement.classList.add('bg-green-500', 'text-white'); // Verde accesso
        if (countdownElement) {
            countdownElement.innerHTML = '<span style="font-weight:bold;color:white;"><i class="bi bi-check-circle-fill"></i> COMPLETATA!!!</span>';
        }
        return;
    }

    // Se la task è nella colonna Expired
    if (isExpired) {
        // Colore per le task scadute (es. rosso scuro)
        taskElement.classList.add('bg-red-800', 'text-white');
        if (countdownElement) {
            countdownElement.innerHTML = '<span style="font-weight:bold;color:white;"><i class="bi bi-x-circle-fill"></i> SCADUTA!</span>';
        }
        return;
    }

    if (!dueDateString) return;

    // Get time in milliseconds
    const targetDate = new Date(dueDateString).getTime();
    const now = new Date().getTime();
    const distance = targetDate - now;

    // Calcola distanza in giorni (arrotondata per difetto)
    const distanceInDays = Math.floor(distance / (1000 * 60 * 60 * 24));

    if (distance <= 0) {
        // La task è scaduta ma non è ancora stata spostata
        // La funzione checkAndMoveExpiredTask si occuperà dello spostamento
        taskElement.classList.add('bg-red-600', 'text-white'); // Rosso acceso temporaneo
        if (countdownElement) {
             countdownElement.innerHTML = '<span style="font-weight:bold;color:#fff;"><i class="bi bi-x-circle-fill"></i> SCADUTA!</span>';
        }
    } else if (distanceInDays > 7) {
        taskElement.classList.add('bg-green-500', 'text-white'); // verde acceso (> 7gg)
    } else if (distanceInDays >= 1) {
        taskElement.classList.add('bg-orange-500', 'text-white'); // arancione accesso (1-7gg)
    } else {
        // Meno di un giorno
        taskElement.classList.add('bg-red-600', 'text-white'); // rosso acceso (< 1gg)
    }
};

// Nuova funzione per controllare e spostare la task se scaduta
const checkAndMoveExpiredTask = (taskElement, distance) => {
    // Controlla se la task è già in Done o Expired
    if (taskElement.closest('.done-col') || taskElement.closest('.expired-col')) {
        return false;
    }

    if (distance <= 0) {
        stopTaskCountdown(taskElement);
        // Trova la colonna "Expired"
        const expiredColumn = columnsContainer.querySelector('.expired-col .tasks');
        if (expiredColumn) {
            // Sposta la task
            expiredColumn.appendChild(taskElement);
            // Aggiorna colore e contatori dopo lo spostamento
            updateTaskColor(taskElement);
            return true;
        }
    }
    return false;
};

// Countdown
const updateCountdown = (taskElement) => {
    const countdownElement = taskElement.querySelector('.task-countdown');
    const dueDateString = countdownElement.getAttribute('data-due-date');
    if (!dueDateString) return;

    const targetDate = new Date(dueDateString).getTime();
    const now = new Date().getTime();
    let distance = targetDate - now;

    // *** NUOVO: Controlla e sposta la task se scaduta ***
    if (checkAndMoveExpiredTask(taskElement, distance)) {
        // Se la task è stata spostata, la funzione si interrompe qui
        return;
    }

    const days = Math.floor(distance / (1000 * 60 * 60 * 24));
    distance %= (1000 * 60 * 60 * 24);
    const hours = Math.floor(distance / (1000 * 60 * 60));
    distance %= (1000 * 60 * 60);
    const minutes = Math.floor(distance / (1000 * 60));
    distance %= (1000 * 60);
    const seconds = Math.floor(distance / 1000);

    countdownElement.innerHTML = `
        <span class="countdown font-mono text-sm"><span style="--value:${days};">${formatTime(days)}</span>g</span>
        <span class="countdown font-mono text-sm"><span style="--value:${hours};">${formatTime(hours)}</span>h</span>
        <span class="countdown font-mono text-sm"><span style="--value:${minutes};">${formatTime(minutes)}</span>m</span>
        <span class="countdown font-mono text-sm"><span style="--value:${seconds};">${formatTime(seconds)}</span>s</span>
    `;

    updateTaskColor(taskElement);
};

const startTaskCountdown = (taskElement) => {
    const countdownElement = taskElement.querySelector('.task-countdown');
    if (!countdownElement || !countdownElement.getAttribute('data-due-date')) return;

    // Esegui il check iniziale. Se scaduta, viene spostata e il timer non parte.
    const targetDate = new Date(countdownElement.getAttribute('data-due-date')).getTime();
    const now = new Date().getTime();
    const distance = targetDate - now;

    if (!checkAndMoveExpiredTask(taskElement, distance)) {
        updateCountdown(taskElement);
        const timerId = setInterval(() => updateCountdown(taskElement), 1000);
        countdownElement.timerId = timerId;
    }
};

const stopTaskCountdown = (taskElement) => {
    const countdownElement = taskElement.querySelector('.task-countdown');
    if (countdownElement && countdownElement.timerId) {
        clearInterval(countdownElement.timerId);
        // Rimuovi il timerId per sicurezza, non strettamente necessario ma buona prassi
        delete countdownElement.timerId;
    }
};

// Funzioni drag & drop
const handleDragover = (event) => {
    event.preventDefault();
    const draggedTask = document.querySelector(".dragging");
    const target = event.target.closest(".task, .tasks");
    
    if (!draggedTask || !target || target === draggedTask) return;

    // Impedisce il drop nella colonna Expired se non è la task a essere già lì
    if (target.closest('.expired-col') && !draggedTask.closest('.expired-col')) {
        return;
    }
    
    // Logica di riordinamento
    if (target.classList.contains("tasks")) {
        const lastTask = target.lastElementChild;
        if (!lastTask || lastTask === draggedTask) {
            target.appendChild(draggedTask);
        } else {
            const { bottom } = lastTask.getBoundingClientRect();
            if (event.clientY > bottom) target.appendChild(draggedTask);
        }
    } else {
        const { top, height } = target.getBoundingClientRect();
        const distance = top + height / 2;
        if (event.clientY < distance) {
            target.before(draggedTask);
        } else {
            target.after(draggedTask);
        }
    }
};

const handleDrop = (event) => {
    event.preventDefault();
    const draggedTask = document.querySelector(".dragging");
    if (draggedTask) {
        // Dopo il drop, aggiorna la visualizzazione
        stopTaskCountdown(draggedTask);
        // Riattiva il countdown se necessario e aggiorna il colore
        if (draggedTask.querySelector('.task-countdown')?.getAttribute('data-due-date')) {
            startTaskCountdown(draggedTask);
        } else {
             // Se non ha scadenza, aggiorna solo il colore se è in Done (per sicurezza)
             updateTaskColor(draggedTask);
        }
    }
};

const handleDragend = (event) => {
    event.target.classList.remove("dragging");
    // Al termine del drag, aggiorna i contatori delle colonne
    observeTaskChanges(); // La funzione observeTaskChanges esegue l'aggiornamento
};

const handleDragstart = (event) => {
    event.dataTransfer.effectsAllowed = "move";
    event.dataTransfer.setData("text/plain", "");
    requestAnimationFrame(() => event.target.classList.add("dragging"));
};

// Task management
const handleDelete = (event) => {
    currentTask = event.target.closest(".task");
    modal.querySelector(".preview").innerText = currentTask.querySelector('.card-title').innerText.substring(0, 100);
    modal.showModal();
};

const handleEdit = (event) => {
    const task = event.target.closest(".task");
    const taskTitle = task.querySelector('.card-title');
    const input = createTaskInput(taskTitle.innerText);
    taskTitle.replaceWith(input);
    input.focus();

    const selection = window.getSelection();
    selection.selectAllChildren(input);
    selection.collapseToEnd();
};

const handleBlur = (event) => {
    const input = event.target;
    const content = input.innerText.trim() || "Untitled";
    const newTitle = document.createElement('h2');
    newTitle.className = "card-title";
    newTitle.innerHTML = content.replace(/\n/g, "<br>");
    const task = input.closest('.task');
    input.replaceWith(newTitle);
};

const handleAdd = (event) => {
    const tasksEl = event.target.closest(".column").lastElementChild;
    const input = createTaskInput();
    tasksEl.appendChild(input);
    input.focus();
};

const updateTaskCount = (column) => {
    const tasks = column.querySelector(".tasks").children;
    const taskCount = tasks.length;
    column.querySelector(".column-title h3").dataset.tasks = taskCount;
};

const observeTaskChanges = () => {
    columns = document.querySelectorAll(".column");
    for (const column of columns) {
        // Rimuovi l'observer esistente per evitare duplicati
        if (column.observer) {
            column.observer.disconnect();
            delete column.observer;
        }

        // Crea un nuovo observer e inizializza il contatore
        const observer = new MutationObserver(() => updateTaskCount(column));
        observer.observe(column.querySelector(".tasks"), { childList: true });
        column.observer = observer;
        updateTaskCount(column); // Aggiorna il contatore subito
    }
};

// Categorie
const defaultCategories = [
    { name: "To Do", class: "todo-col" },
    { name: "In Progress", class: "inprogress-col" },
    { name: "For Review", class: "review-col" },
    { name: "Done", class: "done-col" },
    // Aggiunta della categoria Expired
    { name: "Expired", class: "expired-col" }
];

function createCategory({ name, class: className }, removable = false) {
    const col = document.createElement("div");
    col.className = `column ${className || ""}`;
    
    // Determina se mostrare il pulsante di rimozione (X)
    // Non lo mostriamo se la categoria è "Done" o "Expired"
    const showRemoveButton = removable && className !== 'done-col' && className !== 'expired-col' && className !== 'todo-col' && className !== 'inprogress-col' && className !== 'review-col';
    ;
    
    // Determina se mostrare il pulsante "Aggiungi Task" (+)
    // Non lo mostriamo se la categoria è "Expired"
    const showAddButton = className !== 'expired-col';

    col.innerHTML = `
        <div class="column-title">
            <h3 data-tasks="0">${name}</h3>
            ${showRemoveButton ? '<button class="remove-category-btn" title="Rimuovi categoria">&times;</button>' : ""}
            ${showAddButton ? '<button data-add class="btn btn-circle btn-success btn-s ms-auto"><i class="bi bi-plus"></i></button>' : ''}
        </div>
        <div class="tasks"></div>
    `;
    const tasksEl = col.querySelector(".tasks");
    tasksEl.addEventListener("dragover", handleDragover);
    tasksEl.addEventListener("drop", handleDrop);
    return col;
}

// Inizializza
columnsContainer.innerHTML = "";
// Passa 'true' a createCategory per le colonne che possono essere rimosse (le custom)
defaultCategories.forEach(cat => {
    // Rendiamo rimovibile solo la colonna "For Review" per default
    const isRemovableDefault = cat.class === 'review-col'; 
    columnsContainer.appendChild(createCategory(cat, isRemovableDefault));
});
observeTaskChanges();

const addCategoryBtn = document.createElement("button");
addCategoryBtn.textContent = "+ Nuova Categoria";
addCategoryBtn.className = "btn btn-primary mt-4";
addCategoryBtn.onclick = () => {
    const name = prompt("Nome nuova categoria?");
    if (name) {
        // Inserisce la nuova categoria prima di 'Done' e 'Expired'
        const doneCol = columnsContainer.querySelector('.done-col');
        columnsContainer.insertBefore(createCategory({ name }, true), doneCol);
        observeTaskChanges();
    }
};
const mainContainer = columnsContainer.closest('.container');
mainContainer ? mainContainer.appendChild(addCategoryBtn) : columnsContainer.parentElement.insertBefore(addCategoryBtn, columnsContainer.nextSibling);

// Delegazioni
columnsContainer.addEventListener("click", e => {
    if (e.target.classList.contains("remove-category-btn")) {
        e.target.closest(".column").remove();
        observeTaskChanges();
    }
});

columnsContainer.addEventListener("click", e => {
    if (e.target.closest("button[data-add]")) {
        const tasksEl = e.target.closest(".column").querySelector(".tasks");
        const content = prompt("Nome della nuova task?");
        if (content && content.trim()) {
            const dueDate = prompt("Data e ora di scadenza (es: 2025-12-31T23:59:00)? Lascia vuoto per nessuna scadenza.");
            const newTask = createTask(content.trim(), dueDate);
            tasksEl.appendChild(newTask);
            if (dueDate) startTaskCountdown(newTask);
        }
    } else if (e.target.closest("button[data-edit]")) {
        handleEdit(e);
    } else if (e.target.closest("button[data-delete]")) {
        handleDelete(e);
    }
});

// Crea task
const createTask = (content, dueDate = null) => {
    const task = document.createElement("div");
    task.className = "task card w-full bg-base-100 card-sm shadow-md mb-2";
    task.draggable = true;

    let countdownHTML = '';
    if (dueDate) {
        // Verifica se la data è valida per evitare errori
        const dateCheck = new Date(dueDate);
        if (!isNaN(dateCheck)) {
             countdownHTML = `<div class="task-countdown flex gap-2 justify-end text-xs mt-2" data-due-date="${dueDate}"></div>`;
        } else {
             console.error("Data di scadenza non valida:", dueDate);
             dueDate = null; // Imposta a null se non valida per non avviare il countdown
        }
    }

    task.innerHTML = `
        <div class="card-body p-4">
            <h2 class="card-title">${content}</h2>
            ${countdownHTML}
            <div class="justify-end card-actions mt-2">
                <button data-edit class="btn btn-info btn-xs"><i class="bi bi-pencil-square"></i></button>
                <button data-delete class="btn btn-error btn-xs"><i class="bi bi-trash"></i></button>
            </div>
        </div>
    `;
    task.addEventListener("dragstart", handleDragstart);
    task.addEventListener("dragend", handleDragend);
    
    // Aggiorna il colore subito per le task senza scadenza o appena create
    if (!dueDate) {
        updateTaskColor(task);
    }
    
    return task;
};

const createTaskInput = (text = "") => {
    const input = document.createElement("div");
    input.className = "task-input card-title";
    input.dataset.placeholder = "Task name";
    input.contentEditable = true;
    input.innerText = text;
    input.addEventListener("blur", handleBlur);
    return input;
};

// Eventi finali
document.querySelectorAll(".tasks").forEach(tasksEl => {
    tasksEl.addEventListener("dragover", handleDragover);
    tasksEl.addEventListener("drop", handleDrop);
});

modal.addEventListener("submit", () => {
    if (currentTask) {
        stopTaskCountdown(currentTask);
        currentTask.remove();
        observeTaskChanges();
    }
});
modal.querySelector("#cancel").addEventListener("click", () => modal.close());
modal.addEventListener("close", () => (currentTask = null));

document.addEventListener('DOMContentLoaded', () => {
    // Avvia i countdown per tutte le task esistenti nel DOM
    document.querySelectorAll('.task').forEach(task => {
        startTaskCountdown(task);
    });
});