const fs = require('fs');
const path = require('path');

const JSON_FILE_PATH = path.join(__dirname, 'tasks.json');

export const loadFromLocalStorage = () => {
    try {
        if (fs.existsSync(JSON_FILE_PATH)) {
            const data = fs.readFileSync(JSON_FILE_PATH, 'utf8');
            return JSON.parse(data);
        }
        return [];
    } catch (error) {
        console.error('Error loading data:', error);
        return [];
    }
}

export const saveToLocalStorage = (data) => {
    try {
        const dataAsJson = JSON.stringify(data, null, 2);
        fs.writeFileSync(JSON_FILE_PATH, dataAsJson, 'utf8');
    } catch (error) {
        console.error('Error saving data:', error);
    }
}