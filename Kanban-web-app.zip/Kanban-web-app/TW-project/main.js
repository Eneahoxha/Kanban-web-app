const modal = document.querySelector(".confirm-modal");
const columnsContainer = document.querySelector(".columns");
let columns = document.querySelectorAll(".column");
const dialog = document.querySelector("dialog");
let currentTask = null;

// Utility
const formatTime = (value) => value < 10 ? `0${value}` : value;

// --- Funzioni Countdown e Colore ---

/**
 * Controlla e sposta la task nella colonna "Expired" se la scadenza è passata
 * e la task non è in "Done" o "Expired".
 * @param {HTMLElement} taskElement - L'elemento task.
 * @param {number} distance - La distanza in millisecondi dalla scadenza.
 * @returns {boolean} True se la task è stata spostata, False altrimenti.
 */
const checkAndMoveExpiredTask = (taskElement, distance) => {
    // Controlla se la task è già in Done o Expired
    if (taskElement.closest('.done-col') || taskElement.closest('.expired-col')) {
        return false;
    }

    if (distance <= 0) {
        stopTaskCountdown(taskElement);
        // Trova la colonna "Expired"
        const expiredColumn = columnsContainer.querySelector('.expired-col .tasks');
        if (expiredColumn) {
            // Sposta la task
            expiredColumn.appendChild(taskElement);
            // Aggiorna colore e contatori dopo lo spostamento
            updateTaskColor(taskElement);
            return true;
        }
    }
    return false;
};

/**
 * Aggiorna la colorazione di una task in base alla sua scadenza e alla colonna.
 * @param {HTMLElement} taskElement - L'elemento task.
 */
const updateTaskColor = (taskElement) => {
    const countdownElement = taskElement.querySelector('.task-countdown');
    const dueDateString = countdownElement?.getAttribute('data-due-date');
    const isDone = taskElement.closest('.done-col');
    const isExpired = taskElement.closest('.expired-col');

    // Rimuovi tutte le classi di colore esistenti
    taskElement.classList.remove(
        'bg-green-100', 'bg-yellow-100', 'bg-red-100', 
        'bg-green-500', 'bg-yellow-400', 'bg-red-600', 'bg-lime-500', 'bg-orange-500', 'bg-pink-600', 'bg-red-800', 'text-white'
    );

    // Se la task è nella colonna Done
    if (isDone) {
        taskElement.classList.add('bg-green-500', 'text-white');
        if (countdownElement) {
            countdownElement.innerHTML = '<span style="font-weight:bold;color:white;"><i class="bi bi-check-circle-fill"></i> COMPLETATA!!!</span>';
        }
        return;
    }

    // Se la task è nella colonna Expired
    if (isExpired) {
        taskElement.classList.add('bg-red-800', 'text-white');
        if (countdownElement) {
            countdownElement.innerHTML = '<span style="font-weight:bold;color:white;"><i class="bi bi-x-circle-fill"></i> SCADUTA!</span>';
        }
        return;
    }

    if (!dueDateString) return;

    // Calcolo distanza
    const targetDate = new Date(dueDateString).getTime();
    const now = new Date().getTime();
    const distance = targetDate - now;
    const distanceInDays = Math.floor(distance / (1000 * 60 * 60 * 24));

    // Logica di colorazione per task non "Done" o "Expired"
    if (distance <= 0) {
        taskElement.classList.add('bg-red-600', 'text-white'); // Scaduta, ma ancora non spostata
        if (countdownElement) {
            countdownElement.innerHTML = '<span style="font-weight:bold;color:#fff;"><i class="bi bi-x-circle-fill"></i> SCADUTA!</span>';
        }
    } else if (distanceInDays > 7) {
        taskElement.classList.add('bg-green-500', 'text-white');
    } else if (distanceInDays >= 1) {
        taskElement.classList.add('bg-orange-500', 'text-white');
    } else {
        taskElement.classList.add('bg-red-600', 'text-white');
    }
};

/**
 * Aggiorna l'innerHTML del countdown e il colore della task.
 * @param {HTMLElement} taskElement - L'elemento task.
 */
const updateCountdown = (taskElement) => {
    const countdownElement = taskElement.querySelector('.task-countdown');
    const dueDateString = countdownElement?.getAttribute('data-due-date');
    if (!dueDateString) return;

    const targetDate = new Date(dueDateString).getTime();
    const now = new Date().getTime();
    let distance = targetDate - now;

    // Controlla e sposta la task se scaduta
    if (checkAndMoveExpiredTask(taskElement, distance)) {
        return;
    }

    // Se è scaduta ma non c'è la colonna expired, la gestiamo come nel Codice 1
    if (distance < 0) {
        if (countdownElement.timerId) clearInterval(countdownElement.timerId);
        updateTaskColor(taskElement);
        return;
    }

    const days = Math.floor(distance / (1000 * 60 * 60 * 24));
    distance %= (1000 * 60 * 60 * 24);
    const hours = Math.floor(distance / (1000 * 60 * 60));
    distance %= (1000 * 60 * 60);
    const minutes = Math.floor(distance / (1000 * 60));
    distance %= (1000 * 60);
    const seconds = Math.floor(distance / 1000);

    countdownElement.innerHTML = `
        <span class="countdown font-mono text-sm"><span style="--value:${formatTime(days)};">${formatTime(days)}</span>g</span>
        <span class="countdown font-mono text-sm"><span style="--value:${formatTime(hours)};">${formatTime(hours)}</span>h</span>
        <span class="countdown font-mono text-sm"><span style="--value:${formatTime(minutes)};">${formatTime(minutes)}</span>m</span>
        <span class="countdown font-mono text-sm"><span style="--value:${formatTime(seconds)};">${formatTime(seconds)}</span>s</span>
    `;

    updateTaskColor(taskElement);
};

const startTaskCountdown = (taskElement) => {
    const countdownElement = taskElement.querySelector('.task-countdown');
    if (!countdownElement || !countdownElement.getAttribute('data-due-date')) return;

    const targetDate = new Date(countdownElement.getAttribute('data-due-date')).getTime();
    const now = new Date().getTime();
    const distance = targetDate - now;

    // Esegui il check iniziale. Se scaduta, viene spostata e il timer non parte.
    if (!checkAndMoveExpiredTask(taskElement, distance)) {
        updateCountdown(taskElement);
        if (countdownElement.timerId) clearInterval(countdownElement.timerId);
        const timerId = setInterval(() => updateCountdown(taskElement), 1000);
        countdownElement.timerId = timerId;
    }
};

const stopTaskCountdown = (taskElement) => {
    const countdownElement = taskElement.querySelector('.task-countdown');
    if (countdownElement && countdownElement.timerId) {
        clearInterval(countdownElement.timerId);
        delete countdownElement.timerId;
    }
};

// --- Funzioni Drag & Drop e Task Management (Mantenute Inalterate) ---

const handleDragover = (event) => {
    event.preventDefault();
    const draggedTask = document.querySelector(".dragging");
    const target = event.target.closest(".task, .tasks");

    if (!draggedTask || !target || target === draggedTask) return;

    if (target.closest('.expired-col') && !draggedTask.closest('.expired-col')) {
        return;
    }

    if (target.classList.contains("tasks")) {
        const lastTask = target.lastElementChild;
        if (!lastTask || lastTask === draggedTask) {
            target.appendChild(draggedTask);
        } else {
            const { bottom } = lastTask.getBoundingClientRect();
            if (event.clientY > bottom) target.appendChild(draggedTask);
        }
    } else {
        const { top, height } = target.getBoundingClientRect();
        const distance = top + height / 2;
        if (event.clientY < distance) {
            target.before(draggedTask);
        } else {
            target.after(draggedTask);
        }
    }
};

const handleDrop = (event) => {
    event.preventDefault();
    const draggedTask = document.querySelector(".dragging");
    if (draggedTask) {
        stopTaskCountdown(draggedTask);

        if (draggedTask.querySelector('.task-countdown')?.getAttribute('data-due-date')) {
            startTaskCountdown(draggedTask);
        } else {
            updateTaskColor(draggedTask);
        }
    }
};

const handleDragend = (event) => {
    event.target.classList.remove("dragging");
    observeTaskChanges();
};

const handleDragstart = (event) => {
    event.dataTransfer.effectsAllowed = "move";
    event.dataTransfer.setData("text/plain", "");
    requestAnimationFrame(() => event.target.classList.add("dragging"));
};

const handleDelete = (event) => {
    currentTask = event.target.closest(".task");
    modal.querySelector(".preview").innerText = currentTask.querySelector('.card-title').innerText.substring(0, 100);
    modal.showModal();
};

const handleEdit = (event) => {
    const task = event.target.closest(".task");
    const taskTitle = task.querySelector('.card-title');
    const input = createTaskInput(taskTitle.innerText);
    taskTitle.replaceWith(input);
    input.focus();

    const selection = window.getSelection();
    selection.selectAllChildren(input);
    selection.collapseToEnd();
};

const handleBlur = (event) => {
    const input = event.target;
    const content = input.innerText.trim() || "Untitled";
    const newTitle = document.createElement('h2');
    newTitle.className = "card-title";
    newTitle.innerHTML = content.replace(/\n/g, "<br>");
    const task = input.closest('.task');
    input.replaceWith(newTitle);
};

const updateTaskCount = (column) => {
    const tasks = column.querySelector(".tasks").children;
    const taskCount = tasks.length;
    column.querySelector(".column-title h3").dataset.tasks = taskCount;
};

const observeTaskChanges = () => {
    columns = document.querySelectorAll(".column");
    for (const column of columns) {
        if (column.observer) {
            column.observer.disconnect();
            delete column.observer;
        }

        const tasksEl = column.querySelector(".tasks");
        if (!tasksEl) continue;

        const observer = new MutationObserver(() => updateTaskCount(column));
        observer.observe(tasksEl, { childList: true });
        column.observer = observer;
        updateTaskCount(column);
    }
};

// Crea task
const createTask = (content, dueDate = null) => {
    const task = document.createElement("div");
    task.className = "task card w-full bg-base-100 card-sm shadow-md mb-2";
    task.draggable = true;

    let countdownHTML = '';
    let validDueDate = dueDate;

    if (dueDate) {
        const dateCheck = new Date(dueDate);
        if (!isNaN(dateCheck.getTime())) {
            countdownHTML = `<div class="task-countdown flex gap-2 justify-end text-xs mt-2" data-due-date="${dueDate}"></div>`;
        } else {
            console.error("Data di scadenza non valida:", dueDate);
            validDueDate = null;
        }
    }

    task.innerHTML = `
        <div class="card-body p-4">
            <h2 class="card-title">${content}</h2>
            ${countdownHTML}
            <div class="justify-end card-actions mt-2">
                <button data-edit class="btn btn-info btn-xs"><i class="bi bi-pencil-square"></i></button>
                <button data-delete class="btn btn-error btn-xs"><i class="bi bi-trash"></i></button>
            </div>
        </div>
    `;
    task.addEventListener("dragstart", handleDragstart);
    task.addEventListener("dragend", handleDragend);

    if (!validDueDate) {
        updateTaskColor(task);
    }
    return task;
};

const createTaskInput = (text = "") => {
    const input = document.createElement("div");
    input.className = "task-input card-title";
    input.dataset.placeholder = "Task name";
    input.contentEditable = true;
    input.innerText = text;
    input.addEventListener("blur", handleBlur);
    return input;
};

// --- Categorie (Logica FAB Aggiunta) ---

const defaultCategories = [
    { name: "To Do", class: "todo-col" },
    { name: "In Progress", class: "inprogress-col" },
    { name: "For Review", class: "review-col" }, 
    { name: "Done", class: "done-col" },
    { name: "Expired", class: "expired-col" } // Aggiunta la categoria Expired
];

function createCategory({ name, class: className }, removable = false) {
    const col = document.createElement("div");
    col.className = `column ${className || ""}`;

    const protectedClasses = ['todo-col', 'inprogress-col', 'review-col', 'done-col', 'expired-col'];
    const showRemoveButton = removable && !protectedClasses.includes(className);

    const showAddButton = className !== 'expired-col';

    col.innerHTML = `
        <div class="column-title">
            <h3 data-tasks="0">${name}</h3>
            ${showRemoveButton ? '<button class="remove-category-btn" title="Rimuovi categoria">&times;</button>' : ""}
        </div>
        <div class="tasks"></div>
    `;
    const tasksEl = col.querySelector(".tasks");
    tasksEl.addEventListener("dragover", handleDragover);
    tasksEl.addEventListener("drop", handleDrop);
    return col;
}

// *** NUOVA FUNZIONE: Logica di aggiunta task unificata (per il FAB) ***
const handleAddTaskFromFab = () => {
    const content = prompt("Nome della nuova task?");
    if (content && content.trim()) {
        const dueDate = prompt("Data e ora di scadenza (es: 2025-12-31T23:59:00)? Lascia vuoto per nessuna scadenza.");
        const newTask = createTask(content.trim(), dueDate);
        
        // Seleziona la colonna "To Do" per inserire la nuova task
        const tasksEl = columnsContainer.querySelector('.todo-col .tasks'); 
        if (tasksEl) {
            tasksEl.appendChild(newTask);
            if (dueDate) startTaskCountdown(newTask);
        } else {
            console.error("Colonna 'To Do' non trovata.");
        }
    }
};

// *** NUOVA FUNZIONE: Logica di aggiunta categoria unificata (per il FAB) ***
const handleAddCategory = () => {
    const name = prompt("Nome nuova categoria?");
    if (name) {
        // Inserisce la nuova categoria prima di 'Done' e 'Expired'
        const doneCol = columnsContainer.querySelector('.done-col');
        columnsContainer.insertBefore(createCategory({ name }, true), doneCol);
        observeTaskChanges();
    }
};

// --- Inizializzazione ---

columnsContainer.innerHTML = "";
defaultCategories.forEach(cat => {
    const isRemovableDefault = cat.class === 'review-col';
    columnsContainer.appendChild(createCategory(cat, isRemovableDefault));
});
observeTaskChanges();

// --- Delegazioni Eventi ---

// Rimozione Categoria
columnsContainer.addEventListener("click", e => {
    if (e.target.classList.contains("remove-category-btn")) {
        e.target.closest(".column").remove();
        observeTaskChanges();
    }
});

// Aggiunta/Modifica/Eliminazione Task (logica per i pulsanti (+) interni)
columnsContainer.addEventListener("click", e => {
    if (e.target.closest("button[data-add]")) {
        // Logica per i pulsanti '+' interni alle colonne
        const tasksEl = e.target.closest(".column").querySelector(".tasks");
        const content = prompt("Nome della nuova task?");
        if (content && content.trim()) {
            const dueDate = prompt("Data e ora di scadenza (es: 2025-12-31T23:59:00)? Lascia vuoto per nessuna scadenza.");
            const newTask = createTask(content.trim(), dueDate);
            tasksEl.appendChild(newTask);
            if (dueDate) startTaskCountdown(newTask);
        }
    } else if (e.target.closest("button[data-edit]")) {
        handleEdit(e);
    } else if (e.target.closest("button[data-delete]")) {
        handleDelete(e);
    }
});

// --- Eventi Modali e Inizializzazione Finale ---

document.querySelectorAll(".tasks").forEach(tasksEl => {
    tasksEl.addEventListener("dragover", handleDragover);
    tasksEl.addEventListener("drop", handleDrop);
});

modal.addEventListener("submit", () => {
    if (currentTask) {
        stopTaskCountdown(currentTask);
        currentTask.remove();
        observeTaskChanges();
    }
});
modal.querySelector("#cancel").addEventListener("click", () => modal.close());
modal.addEventListener("close", () => (currentTask = null));

// Avvia i countdown e collega i pulsanti FAB all'inizializzazione del DOM
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.task').forEach(task => {
        startTaskCountdown(task);
    });
    
    // Collega l'evento al pulsante FAB #NuovaCategoria
    const fabCategoryBtn = document.getElementById('NuovaCategoria');
    if (fabCategoryBtn) {
        fabCategoryBtn.addEventListener('click', handleAddCategory);
    }
    
    // Collega l'evento al pulsante FAB #NuovaTask
    const fabTaskBtn = document.querySelector('[data-add="NuovaTask"]');
    if (fabTaskBtn) {
        fabTaskBtn.addEventListener('click', handleAddTaskFromFab);
    }
});