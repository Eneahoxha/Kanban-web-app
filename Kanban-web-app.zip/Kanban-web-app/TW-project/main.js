const modal = document.querySelector(".confirm-modal");
const columnsContainer = document.querySelector(".columns");
let columns = document.querySelectorAll(".column");
const dialog = document.querySelector("dialog");
let currentTask = null;

const STORAGE_KEY = 'kanbanTasks'; // Nome della chiave usata in localStorage

// FUNZIONI DI BASE (LIVELLO 0: Senza Dipendenze Complesse) (rr. 10-30)

// Utility per formattare il tempo con zero iniziale.
const formatTime = (value) => value < 10 ? `0${value}` : value;

// Crea l'elemento DOM per l'input di modifica del titolo della task.
const createTaskInput = (text = "") => {
    const input = document.createElement("div");
    input.className = "task-input card-title";
    input.dataset.placeholder = "Task name";
    input.contentEditable = true;
    input.innerText = text;
    // La gestione dell'evento 'blur' è più complessa (Level 1)
    input.addEventListener("blur", handleBlur); 
    return input;
}; 

// FUNZIONI DI MANIPOLAZIONE DOM/STATO (LIVELLO 1: Dipende da Livello 0) (rr. 31-180)


//Salva lo stato attuale di tutte le task e le loro posizioni in localStorage.
const saveTasks = () => {
    const tasksData = [];
    
    columnsContainer.querySelectorAll('.column').forEach(column => {
        const columnClass = Array.from(column.classList).find(cls => cls.endsWith('-col'));
        
        column.querySelectorAll('.task').forEach(taskElement => {
            const taskTitle = taskElement.querySelector('.card-title').innerHTML.trim(); 
            const dueDate = taskElement.querySelector('.task-countdown')?.getAttribute('data-due-date') || null;

            tasksData.push({
                title: taskTitle,
                dueDate: dueDate,
                column: columnClass 
            });
        });
    });

    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(tasksData));
    } catch (e) {
        console.error("Errore nel salvataggio in localStorage:", e);
    }
}; 

// Aggiorna il contatore delle task in una colonna e salva lo stato.
const updateTaskCount = (column) => {
    const tasks = column.querySelector(".tasks").children;
    const taskCount = tasks.length;
    column.querySelector(".column-title h3").dataset.tasks = taskCount;
}; 

//Avvia l'Observer per aggiornare il conteggio delle task quando cambiano.
const observeTaskChanges = () => {
    columns = document.querySelectorAll(".column");
    for (const column of columns) {
        if (column.observer) {
            column.observer.disconnect();
            delete column.observer;
        }

        const tasksEl = column.querySelector(".tasks");
        if (!tasksEl) continue;

        const observer = new MutationObserver(() => updateTaskCount(column));
        observer.observe(tasksEl, { childList: true });
        column.observer = observer;
        updateTaskCount(column);
    }
}; 

//Ferma il countdown di una task (necessario prima di spostarla o eliminarla).
const stopTaskCountdown = (taskElement) => {
    const countdownElement = taskElement.querySelector('.task-countdown');
    if (countdownElement && countdownElement.timerId) {
        clearInterval(countdownElement.timerId);
        delete countdownElement.timerId;
    }
}; 

/**
 * Aggiorna la colorazione di una task in base alla sua scadenza e alla colonna.
 * Non avvia/ferma il timer, si occupa solo dell'aspetto visivo.
 */
const updateTaskColor = (taskElement) => {
    const countdownElement = taskElement.querySelector('.task-countdown');
    const dueDateString = countdownElement?.getAttribute('data-due-date');
    const isDone = taskElement.closest('.done-col');
    const isExpired = taskElement.closest('.expired-col');

    taskElement.classList.remove(
        'bg-green-100', 'bg-yellow-100', 'bg-red-100', 
        'bg-green-500', 'bg-yellow-400', 'bg-red-600', 'bg-lime-500', 'bg-orange-500', 'bg-pink-600', 'bg-red-800', 'text-white'
    );

    // Done
    if (isDone) {
        taskElement.classList.add('bg-green-500', 'text-white');
        if (countdownElement) {
            countdownElement.innerHTML = '<span style="font-weight:bold;color:white;"><i class="bi bi-check-circle-fill"></i> COMPLETATA!!!</span>';
        }
        return;
    }

    // Expired
    if (isExpired) {
        taskElement.classList.add('bg-red-800', 'text-white');
        if (countdownElement) {
            countdownElement.innerHTML = '<span style="font-weight:bold;color:white;"><i class="bi bi-x-circle-fill"></i> SCADUTA!</span>';
        }
        return;
    }

    if (!dueDateString) return;

    // Colore in base alla distanza
    const targetDate = new Date(dueDateString).getTime();
    const now = new Date().getTime();
    const distance = targetDate - now;
    const distanceInDays = Math.floor(distance / (1000 * 60 * 60 * 24));

    if (distance <= 0) {
        taskElement.classList.add('bg-red-600', 'text-white'); 
        if (countdownElement) {
            countdownElement.innerHTML = '<span style="font-weight:bold;color:#fff;"><i class="bi bi-x-circle-fill"></i> SCADUTA!</span>';
        }
    } else if (distanceInDays > 7) {
        taskElement.classList.add('bg-green-500', 'text-white');
    } else if (distanceInDays >= 1) {
        taskElement.classList.add('bg-orange-500', 'text-white');
    } else {
        taskElement.classList.add('bg-red-600', 'text-white');
    }
};

//Controlla e sposta la task nella colonna "Expired" se la scadenza è passata.
const checkAndMoveExpiredTask = (taskElement, distance) => {
    if (taskElement.closest('.done-col') || taskElement.closest('.expired-col')) {
        return false;
    }

    if (distance <= 0) {
        stopTaskCountdown(taskElement);
        const expiredColumn = columnsContainer.querySelector('.expired-col .tasks');
        if (expiredColumn) {
            expiredColumn.appendChild(taskElement);
            updateTaskColor(taskElement);
            saveTasks(); 
            return true;
        }
    }
    return false;
}; 

// COSTRUTTORI E HANDLERS DI BASE (LIVELLO 2: Dipende da Livello 1/Utility) (rr. 181-349)


//Aggiorna l'innerHTML del countdown (chiamata ogni secondo da startTaskCountdown).
const updateCountdown = (taskElement) => {
    const countdownElement = taskElement.querySelector('.task-countdown');
    const dueDateString = countdownElement?.getAttribute('data-due-date');
    if (!dueDateString) return;

    const targetDate = new Date(dueDateString).getTime();
    const now = new Date().getTime();
    let distance = targetDate - now;

    if (checkAndMoveExpiredTask(taskElement, distance)) {
        return;
    }

    if (distance < 0) {
        if (countdownElement.timerId) clearInterval(countdownElement.timerId);
        updateTaskColor(taskElement);
        return;
    }

    const days = Math.floor(distance / (1000 * 60 * 60 * 24));
    distance %= (1000 * 60 * 60 * 24);
    const hours = Math.floor(distance / (1000 * 60 * 60));
    distance %= (1000 * 60 * 60);
    const minutes = Math.floor(distance / (1000 * 60));
    distance %= (1000 * 60);
    const seconds = Math.floor(distance / 1000);

    countdownElement.innerHTML = `
        <span class="countdown font-mono text-sm"><span style="--value:${formatTime(days)};">${formatTime(days)}</span>g</span>
        <span class="countdown font-mono text-sm"><span style="--value:${formatTime(hours)};">${formatTime(hours)}</span>h</span>
        <span class="countdown font-mono text-sm"><span style="--value:${formatTime(minutes)};">${formatTime(minutes)}</span>m</span>
        <span class="countdown font-mono text-sm"><span style="--value:${formatTime(seconds)};">${formatTime(seconds)}</span>s</span>
    `;

    updateTaskColor(taskElement);
}; 

//Avvia il countdown e l'intervallo di aggiornamento per una task.
const startTaskCountdown = (taskElement) => {
    const countdownElement = taskElement.querySelector('.task-countdown');
    if (!countdownElement || !countdownElement.getAttribute('data-due-date')) return;

    const targetDate = new Date(countdownElement.getAttribute('data-due-date')).getTime();
    const now = new Date().getTime();
    const distance = targetDate - now;

    if (!checkAndMoveExpiredTask(taskElement, distance)) {
        updateCountdown(taskElement);
        if (countdownElement.timerId) clearInterval(countdownElement.timerId);
        const timerId = setInterval(() => updateCountdown(taskElement), 1000);
        countdownElement.timerId = timerId;
    }
}; 


// Crea l'elemento DOM per una nuova task.
const createTask = (content, dueDate = null) => {
    const task = document.createElement("div");
    task.className = "task card w-full bg-base-100 card-sm shadow-md mb-2";
    task.draggable = true;

    let countdownHTML = '';
    let validDueDate = dueDate;

    if (dueDate) {
        const dateCheck = new Date(dueDate);
        if (!isNaN(dateCheck.getTime())) {
            countdownHTML = `<div class="task-countdown flex gap-2 justify-end text-xs mt-2" data-due-date="${dueDate}"></div>`;
        } else {
            console.error("Data di scadenza non valida:", dueDate);
            validDueDate = null;
        }
    }

    task.innerHTML = `
        <div class="card-body p-4">
            <h2 class="card-title">${content}</h2>
            ${countdownHTML}
            <div class="justify-end card-actions mt-2">
                <button data-edit class="btn btn-info btn-xs"><i class="bi bi-pencil-square"></i></button>
                <button data-delete class="btn btn-error btn-xs"><i class="bi bi-trash"></i></button>
            </div>
        </div>
    `;
    task.addEventListener("dragstart", handleDragstart);
    task.addEventListener("dragend", handleDragend);

    if (!validDueDate) {
        updateTaskColor(task);
    }
    return task;
}; 


//Handler per il 'blur' dell'input di modifica del titolo.
const handleBlur = (event) => {
    const input = event.target;
    const content = input.innerText.trim() || "Untitled";
    const newTitle = document.createElement('h2');
    newTitle.className = "card-title";
    newTitle.innerHTML = content.replace(/\n/g, "<br>");
    const task = input.closest('.task');
    input.replaceWith(newTitle);
    
    saveTasks(); 
};

/**
 * Handler per l'avvio del drag.
 */
const handleDragstart = (event) => {
    if (event.target.closest('.expired-col')) { 
        event.preventDefault(); 
        return;
    }
    event.dataTransfer.effectsAllowed = "move";
    event.dataTransfer.setData("text/plain", "");
    requestAnimationFrame(() => event.target.classList.add("dragging"));
};

/**
 * Handler per la fine del drag.
 * Dipende da: observeTaskChanges.
 */
const handleDragend = (event) => {
    event.target.classList.remove("dragging");
    observeTaskChanges();
};

/**
 * Handler per l'editing di una task.
 * Dipende da: createTaskInput.
 */
const handleEdit = (event) => {
    const task = event.target.closest(".task");
    const taskTitle = task.querySelector('.card-title');
    const input = createTaskInput(taskTitle.innerText);
    taskTitle.replaceWith(input);
    input.focus();

    const selection = window.getSelection();
    selection.selectAllChildren(input);
    selection.collapseToEnd();
};

/**
 * Handler per l'eliminazione di una task (mostra la modale).
 */
const handleDelete = (event) => {
    currentTask = event.target.closest(".task");
    modal.querySelector(".preview").innerText = currentTask.querySelector('.card-title').innerText.substring(0, 100); 
    modal.showModal();
};

// FUNZIONI DI ALTO LIVELLO (LIVELLO 3: Drag/Drop, Categorie, Inizializzazione) (rr. 350-527)

/**
 * Handler per l'evento Dragover (logica di spostamento sul DOM).
 */
const handleDragover = (event) => {
    event.preventDefault();
    const draggedTask = document.querySelector(".dragging");
    const target = event.target.closest(".task, .tasks");

    if (!draggedTask || !target || target === draggedTask) return;

    if (target.closest('.expired-col') && !draggedTask.closest('.expired-col')) {
        event.dataTransfer.dropEffect = "none";
        return;
    }
    
    event.dataTransfer.dropEffect = "move";

    if (target.classList.contains("tasks")) {
        const lastTask = target.lastElementChild;
        if (!lastTask || lastTask === draggedTask) {
            target.appendChild(draggedTask);
        } else {
            const { bottom } = lastTask.getBoundingClientRect();
            if (event.clientY > bottom) target.appendChild(draggedTask);
        }
    } else {
        const { top, height } = target.getBoundingClientRect();
        const distance = top + height / 2;
        if (event.clientY < distance) {
            target.before(draggedTask);
        } else {
            target.after(draggedTask);
        }
    }
};

/**
 * Handler per l'evento Drop (logica dopo il rilascio).
 * Dipende da: stopTaskCountdown, startTaskCountdown, updateTaskColor, saveTasks.
 */
const handleDrop = (event) => {
    event.preventDefault();
    const draggedTask = document.querySelector(".dragging");
    const targetColumn = event.target.closest(".column"); 

    if (draggedTask && targetColumn && 
        targetColumn.classList.contains('expired-col') && 
        !draggedTask.closest('.expired-col')) {
        
        draggedTask.classList.remove("dragging");
        return; 
    }

    if (draggedTask) {
        stopTaskCountdown(draggedTask);

        if (draggedTask.querySelector('.task-countdown')?.getAttribute('data-due-date')) {
            startTaskCountdown(draggedTask);
        } else {
            updateTaskColor(draggedTask);
        }
        
        saveTasks(); 
    }
};

/**
 * Crea l'elemento DOM per una categoria (colonna).
 * Dipende da: handleDragover, handleDrop.
 */
function createCategory({ name, class: className }, removable = false) {
    const col = document.createElement("div");
    col.className = `column ${className || ""}`;

    const protectedClasses = ['todo-col', 'inprogress-col', 'review-col', 'done-col', 'expired-col'];
    const showRemoveButton = removable && !protectedClasses.includes(className);
    
    // Il pulsante di aggiunta task (+) interno
    const showAddButton = className !== 'expired-col'; 

    col.innerHTML = `
        <div class="column-title">
            <h3 data-tasks="0">${name}</h3>
            ${showRemoveButton ? '<button class="remove-category-btn" title="Rimuovi categoria">&times;</button>' : ""}
        </div>
        <div class="tasks"></div>
    `;
    const tasksEl = col.querySelector(".tasks");
    tasksEl.addEventListener("dragover", handleDragover);
    tasksEl.addEventListener("drop", handleDrop);
    return col;
}

// Dati predefiniti per le categorie
const defaultCategories = [
    { name: "To Do", class: "todo-col" },
    { name: "In Progress", class: "inprogress-col" },
    { name: "For Review", class: "review-col" }, 
    { name: "Done", class: "done-col" },
    { name: "Expired", class: "expired-col" }
];

/**
 * Logica di aggiunta task tramite Floating Action Button (FAB).
 * Dipende da: createTask, startTaskCountdown, saveTasks.
 */
const handleAddTaskFromFab = () => {
    const content = prompt("Nome della nuova task?");
    if (content && content.trim()) {
        const dueDate = prompt("Data e ora di scadenza (es: 2025-12-31T23:59:00)? Lascia vuoto per nessuna scadenza.");
        const newTask = createTask(content.trim(), dueDate);
        
        const tasksEl = columnsContainer.querySelector('.todo-col .tasks'); 
        if (tasksEl) {
            tasksEl.appendChild(newTask);
            if (dueDate) startTaskCountdown(newTask);
            saveTasks(); 
        } else {
            console.error("Colonna 'To Do' non trovata.");
        }
    }
};

/**
 * Logica di aggiunta categoria tramite Floating Action Button (FAB).
 * Dipende da: createCategory, observeTaskChanges, saveTasks.
 */
const handleAddCategory = () => {
    const name = prompt("Nome nuova categoria?");
    if (name) {
        const doneCol = columnsContainer.querySelector('.done-col');
        columnsContainer.insertBefore(createCategory({ name }, true), doneCol);
        observeTaskChanges();
        saveTasks(); 
    }
};

/**
 * Carica le task da localStorage e le ricrea nel DOM.
 * Dipende da: createTask, startTaskCountdown, observeTaskChanges.
 */
const loadTasks = () => {
    const savedData = localStorage.getItem(STORAGE_KEY);
    if (!savedData) {
        console.log("Nessun dato salvato trovato. Parto dallo stato predefinito/vuoto.");
        return;
    }

    try {
        const tasksData = JSON.parse(savedData);
        
        tasksData.forEach(taskData => {
            const { title, dueDate, column: columnClass } = taskData;
            
            const tasksEl = columnsContainer.querySelector(`.${columnClass} .tasks`);
            
            if (tasksEl) {
                const newTask = createTask(title, dueDate); 
                tasksEl.appendChild(newTask);
                
                if (dueDate) startTaskCountdown(newTask); 
            } else {
                console.warn(`Colonna ${columnClass} non trovata, task ignorata.`);
            }
        });
        
        observeTaskChanges();

    } catch (e) {
        console.error("Errore nel parsing dei dati salvati:", e);
        localStorage.removeItem(STORAGE_KEY); 
    }
};


// INIZIALIZZAZIONE (LIVELLO 4: Chiamate di avvio) (rr. 528-604)

// --- 1. Inizializzazione Struttura Colonne ---
columnsContainer.innerHTML = "";
defaultCategories.forEach(cat => {
    const isRemovableDefault = cat.class === 'review-col';
    columnsContainer.appendChild(createCategory(cat, isRemovableDefault));
});
observeTaskChanges();

// --- 2. Caricamento Dati Persistenti ---
loadTasks();

// --- 3. Delegazioni Eventi Principali ---

// Gestione rimozione Categoria
columnsContainer.addEventListener("click", e => {
    if (e.target.classList.contains("remove-category-btn")) {
        e.target.closest(".column").remove();
        observeTaskChanges();
        saveTasks(); 
    }
});

// Gestione Aggiunta/Modifica/Eliminazione Task (pulsanti interni alle task/colonne)
columnsContainer.addEventListener("click", e => {
    if (e.target.closest("button[data-add]")) {
        // Logica per i pulsanti '+' interni alle colonne
        const tasksEl = e.target.closest(".column").querySelector(".tasks");
        const content = prompt("Nome della nuova task?");
        if (content && content.trim()) {
            const dueDate = prompt("Data e ora di scadenza (es: 2025-12-31T23:59:00)? Lascia vuoto per nessuna scadenza.");
            const newTask = createTask(content.trim(), dueDate);
            tasksEl.appendChild(newTask);
            if (dueDate) startTaskCountdown(newTask);
            
            saveTasks(); 
        }
    } else if (e.target.closest("button[data-edit]")) {
        handleEdit(e);
    } else if (e.target.closest("button[data-delete]")) {
        handleDelete(e);
    }
});

// Eventi Modali (eliminazione task)
document.querySelectorAll(".tasks").forEach(tasksEl => {
    tasksEl.addEventListener("dragover", handleDragover);
    tasksEl.addEventListener("drop", handleDrop);
});

modal.addEventListener("submit", () => {
    if (currentTask) {
        stopTaskCountdown(currentTask);
        currentTask.remove();
        observeTaskChanges();
        saveTasks(); 
    }
});
modal.querySelector("#cancel").addEventListener("click", () => modal.close());
modal.addEventListener("close", () => (currentTask = null));

// --- 4. Collegamento Pulsanti FAB ---

document.addEventListener('DOMContentLoaded', () => {
    // Collega l'evento al pulsante FAB #NuovaCategoria
    const fabCategoryBtn = document.getElementById('NuovaCategoria');
    if (fabCategoryBtn) {
        fabCategoryBtn.addEventListener('click', handleAddCategory);
    }
    
    // Collega l'evento al pulsante FAB [data-add="NuovaTask"]
    const fabTaskBtn = document.querySelector('[data-add="NuovaTask"]');
    if (fabTaskBtn) {
        fabTaskBtn.addEventListener('click', handleAddTaskFromFab);
    }
});